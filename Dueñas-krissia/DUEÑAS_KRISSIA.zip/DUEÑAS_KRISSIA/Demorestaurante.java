class DemoRestaurante{
	
	public static void main(String[] args) {
		//Utilizando el Constructor Personalizado
		
		Restaurante rel = new Restaurante("tipo_hamburguesa", "tipo_pago","cantidad");
		
		System.out.println("======= RESTAURANTE =======");
		
		rel.setCaptura();
		rel.Restaurante(rel.setCaptura());
		
	
	}
	
}