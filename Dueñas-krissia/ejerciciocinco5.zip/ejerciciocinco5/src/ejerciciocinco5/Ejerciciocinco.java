/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciocinco5;
import java.util.Scanner;
/**
 *
 * @author user
 */
public class Ejerciciocinco5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner l = new Scanner(System.in);
        fiesta n = new fiesta();
        String genero;
        
      
        n.fiesta();
        genero=l.nextLine();
        n.fiesta(genero);
        
    }
        // TODO code application logic here
    }
    


        